package com.example.firstproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.ktx.Firebase;

public class signup_activity extends AppCompatActivity {
    TextView ret;
    Button signup_button;
    EditText user_email,user_password;
    FirebaseAuth fauth;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        ret = findViewById(R.id.back);

        ret.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(signup_activity.this,MainActivity.class);
                startActivity(i);
            }
        });

        user_email = findViewById(R.id.email);
        user_password = findViewById(R.id.password);
        fauth = FirebaseAuth.getInstance();
        signup_button = findViewById(R.id.signup_button);

        signup_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createUser();
            }

            private void createUser()
            {
                String email_info = user_email.getText().toString();
                String password = user_password.getText().toString();
                fauth.createUserWithEmailAndPassword(email_info,password).addOnCompleteListener(signup_activity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                            Toast.makeText(signup_activity.this,"Successfully Created Your Account",Toast.LENGTH_LONG).show();
                       else
                            Toast.makeText(signup_activity.this,"Email already exists.",Toast.LENGTH_LONG).show();
                    }
                });

            }
        });



    }
}